import java.util.ArrayList;

public class Sintaxe {
    String nome;

    public static void main(String[] args) {

        //Tipos primitivos números: byte < short < int < long:
        byte num_1 = 127;
        short num_2 = 32767;
        int num_3 = 2147483647;
        long num_4 = 800000000; //Maior que tem



        //Decimais: Float < Double:
        float dec_1 = 12.32f; //deve-se por o "f" no final
        double dec_2 = 14123.32;



        //Booleano, string e char:
        String exemplo;
        exemplo = "Exemplo"; //STRING usa aspas "" duplas
        boolean real = true;
        char um_caractere = 'b'; //CHAR usa aspas '' simples



        //"VAR" seleciona automaticamente os tipos:
        var numero_exemplo = 1431;
        var real_fake = false;
        var texto_exemplo = "Var";



        //Printar em Java: System.out.println("texto");
        System.out.println("Hello World!");
        System.out.println(texto_exemplo);



        //Condição em java: IF, ELSE IF e ELSE:
        if(num_4 > num_1) {
            System.out.println("IF = " + num_4);
        }
        else if(num_2 == 32767) {
            System.out.println(num_3);
        }
        //fica em cinza pois essa condição não irá acontecer, já que o "num_4" será
        // sempre maior que o "num_1"




        //ARRAYS: tipo[] nome = {1, 2, 3}
        int[] casas = {12, 43, 52};     //escolhe quais e quantos números terão
        casas[0] = 123;     //substitui o valor escolhido

        int[] idades = new int[20]; //define um tamanho e vai colocando os valores depois:
        idades[2] = 563; //define o valor


        //ARRAY LIST uma lista dinâmica da biblioteca do Java:
        ArrayList<Integer> idade = new ArrayList<Integer>();
        idade.add(50); //adiciona um valor na lista
        idade.add(25); //adiciona um valor na lista
        idade.add(19); //adiciona um valor na lista
        idade.remove(0); //remove um valor da lista
        int tamanho = idade.size(); //peguei um valor da lista e joguei como uma variável
        System.out.println("Size " + tamanho); //mostrei na tela esse valor
        int tirar = idade.get(0); //peguei um valor da lista e joguei como uma variável
        System.out.println("Get " + tirar); //mostrei na tela esse valor




        //estrutura de repetição, FOR:
        int num_5 = 12;

        for(var i = 0; i < num_5; i++){     //(i = 0) --> criei a variável "i" |
            System.out.println("For dentro escopo " + i); //(i < num_5) --> e enquanto o "i" for menor que a variável "num_5"|
                                            //(i++) --> vai adicionando 1 ao "i"|
        //como a variável "i" foi definida dentro do escopo do "for" não é possivel printar fora daí.
        }

        //estrutura de repetição, WHILE:
        int num_6 = 10;
        int a = 0; //<--variável fora do escopo do while

        while(a < num_6){
            a++;
        }
        System.out.println("While por fora " + a);
        //^^possibilitando printar por fora



        //CASTING: tranfomar double em int, int em double, string em int e vice versa
        int idade2 = 92;
        double idade3 = idade2;
        System.out.println("double em int = " + idade3); //resulta em 92.0

        //nao se pode por um double idade3 = idade2 em um inteiro
        //pois o double é maior que o int e você vai acabar perdendo números

        double teste2 = 31.2;
        int teste3 = 12;

        //tranformar char em string:
        char letra = 'p';
        String palavra = String.valueOf(letra) + "aulo"; //método auxiliar *value of*
        System.out.println("Transformar Char em String = " + palavra);

        //string em char:
        letra = palavra.charAt(2);
        System.out.println("String em char = " + letra);

        //int em string:
        int num_7 = 123;
        String valor = String.valueOf(num_7);
        System.out.println("Int em string = " + valor);

        //string em int:
        int num_8 = 423;
        num_8 = Integer.parseInt(valor);
        System.out.println(num_8);
        int teste = num_8 + 12; //<-- testando se realmente virou int
    }
}

