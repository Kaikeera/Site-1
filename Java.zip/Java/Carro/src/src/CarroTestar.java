package src;

public class CarroTestar {
    public static void main(String[] args) {

        Carro c1 = new Carro();

        c1.nome = "X5";
        c1.marca = "Bmw";
        c1.ano = 2022;
        c1.vel = 130;

        c1.acelerar(70);

        System.out.println("Velocidade: " + c1.vel + "km/h");

        c1.freiar(50);

        System.out.println("Velocidade depois de freiar: " + c1.vel + "km/h");
        
    }

}